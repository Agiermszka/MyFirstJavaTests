package Examples;

public class ExampleBoolean {

    public static void main(String[] args) {
        boolean b;
        b= true;
        System.out.println("b wynosi " + b);
        b= false;
        System.out.println("b wynosi "+ b);

        if (b) System.out.println("To nie zostało wykonane");

        b= true;

        if (b) System.out.println("To zostało wykonane");

        System.out.println("10>9 to wartość " + (8>9));

    }

}
