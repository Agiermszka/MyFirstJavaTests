package Examples;

public class ExampleString {

    public static void main(String[] args) {
        String strOb1 = "Pierwszy tekst";
        String strOb2 = "Drugi tekst";
        String strOb3 = strOb1 + " i " + strOb2;
        System.out.println(strOb3);
    }
}
