package Examples;

public class ExampleScope {

    public static void main(String[] args) {
        int x = 10;
        if (x == 10) {
            int y = 20;

            int suma;
            suma = x + y;
            System.out.println("x+y: " + suma);
            x = y * 2;
        }
        System.out.println("x wynosi " + x); //zwróć uwagę, że x = 40, a nie 10 jeżeli wykonuje blog if!
   }

}
