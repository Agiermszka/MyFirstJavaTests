package Examples;

public class ExampleLifeTime {

    public static void main(String[] args) {
        int x;
        for (x= 0; x< 3; x++); {
            int y = 10;
            System.out.println("y wynosi " + y);
            y = 100;
            System.out.println("y wynosi " + y);
            x= y + 10;
        }
        System.out.println("x wynosi " + x);
    }
}
