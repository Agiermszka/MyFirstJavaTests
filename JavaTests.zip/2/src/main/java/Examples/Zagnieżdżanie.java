package Examples;

public class Zagnieżdżanie {
    public static void main(String[] args) {
        int i = 10;
        int j = 19;
        int k = 99;
        int a = 2, b = 3, c = 4, d = 5;

        if (i == 10) {
            if (j < 20)
                a = b;
            System.out.println("wydrukuj a " + a + " i b " + b);
            if (k > 100) {
                c = d;
            } else {
                System.out.println("wydrukuj coś innego");
                System.out.println("wydrukuj c " + c + " i d " + d);
            } // slajd 73

        } else a = d;
    }
}