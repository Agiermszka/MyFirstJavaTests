package Examples;

//Przykład użycia typu danych char
public class ExampleChar {

    public static void main(String[] args) {
        char ch1, ch2;
        ch1 = 88; //Kod dla x
        ch2 = 'Y';
        System.out.print(" ch1 i ch2: ");
        System.out.println(ch1 + " " + ch2);

        ch1 = 'X';
        System.out.println("ch1 zawiera znak " + ch1);
        ch1++; //Inkrementacja ch1
        System.out.println("teraz ch1 ma wartość " + ch1);

    }

}
