package Examples;

public class ExampleModulus {
    public static void main(String[] args) {
        int x = 42;
        double y = 42.25;

        System.out.println("x modulo 10 = "+ x % 10);
        System.out.println("y modulo 10 = "+ y % 10);
    }
}
