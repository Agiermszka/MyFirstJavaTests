package Examples;

import java.util.Scanner;

public class ExampleĆwiczenie3cdn {

    public static void main(String[] args) {
        //klasa Scanner - ma różnego typu metody umożliwiające komunikajcę z zewnętrznymi urządzeniami

            Scanner klawiatura = new Scanner(System.in);
            System.out.println("Podaj wartosc stopni Celsjusza: ");

            // (klawiatura) to obiekt, roboczo nazwany zmienną
            // klasy Scanner - tworzymy taki obiekt, przez który będziemy się komunikować z urządzeniem
            // będzie powiązany z wejściem systemowym,a In oznacza z klawiaturą
            double stopnieCelsjusza = klawiatura.nextDouble(); // tę zmienną chcę zapamiętać w StCel

            double stopnieFahrenheita;

            stopnieFahrenheita = stopnieCelsjusza * 1.8 + 32;
            System.out.println(stopnieCelsjusza + " stopni Celsjusza, to jest " + stopnieFahrenheita + " stopni Fahrenheita.");
    }
}
