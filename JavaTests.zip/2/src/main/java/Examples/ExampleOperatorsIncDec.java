package Examples;
// Przykład użycia operatora


public class ExampleOperatorsIncDec {

    public static void main(String[] args) {
        int a= 1;
        int b= 2;
        int c;
        int d;
        int e;

        c= ++b;
        d= a++;
        c++;
        e= ++b;

        System.out.println("a= " + a);
        System.out.println("b= " + b);
        System.out.println("c= " + c);
        System.out.println("d= " + d);
        System.out.println("e= " + e);
    }
}
