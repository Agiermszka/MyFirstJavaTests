package Examples;

public class ExampleSampleIf {
    public static void main(String[] args) {
        int x, y;
        x= 10;
        y= 40;

        if(x < y) System.out.println("x równe " + x + " jest mniejsze od y " + y);

        x= x * 2;
        if(x == y) System.out.println("teraz x, które wynosi " + x + " jest równe y ");

        x= x * 2;
        if(x > y) System.out.println("x równe " + x + " jest teraz większe od y " + y);
        // Poniższe wywołanie metody println() nie zostanie wykonane

        if (x == y)
            System.out.println("tego nie zobaczysz");

        String myFirstString = "Some text.";
        String mySecondString = "Some text.";
        System.out.println(myFirstString == mySecondString);

        String myFirstNewString = new String("Some text.");
        String mySecondNewString = new String("Some text.");
        System.out.println(myFirstNewString == mySecondNewString);


    }
}
