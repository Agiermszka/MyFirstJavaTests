public class Pętle {

    public static void main(String[] args) {

        int zmienna = 10;


        System.out.println(" pętla while ");

        while (zmienna >= 3) {
            System.out.println(zmienna);
           // zmienna = zmienna - 1;
            zmienna--;
        }

        System.out.println("koniec pętli while");

        System.out.println("początek pętli do-while");


        int zmienna2 = 10;

        do {
            System.out.println(zmienna2);
            zmienna2--;
        } while (zmienna2 >= 3);

        System.out.println("koniec pętli do-while");


        System.out.println("początek pętli for");

        //pierwszy parametr -> drugi parametr -> instrukcje ->
        //trzeci parametr -> drugi parametr -> instrukcje ->
        //trzeci parametr -> drugi parametr -> instrukcje ->

       for (int zmienna3 = 10; zmienna3 >=3; zmienna3--){
            System.out.println(zmienna3);
                   }

        System.out.println("koniec pętli for");
    }
}
