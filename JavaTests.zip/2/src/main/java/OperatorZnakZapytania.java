public class OperatorZnakZapytania {

    public static void main(String[] args) {

        int x = -5;
        if ( x < 0) {
               x = x * -1; // chcę napisać algorytm, który mi zwróci wartość bezwzględną z podanej wartości
            // x = -x // wyliczanie wartości bezwzględnej 18:30
        } else {
            x = x;
        }

        System.out.println(x);

        //też instrukcja warunkowa

        x = -5; // już wpisane w pudełko

        x= x < 0 ? -x : x; // operator trójargumentowy znak zapytania // konstrukcja warunkowa ?
        System.out.println(x);

    }
}
