public class PracownikDemo {
    public static void main(String[] args) { //tablica - bez tworzenia obiektu

        Pracownik pracownik1 = new Pracownik();
        pracownik1.setImię("Adam");
        pracownik1.setNazwisko("Bogdanka");
        pracownik1.setPensja(2800); // Pracownik.setPensja(2800);
        System.out.println("id = " + Pracownik.id);

        Pracownik pracownik2 = new Pracownik();
        pracownik2.setImię("Zenon");
        pracownik2.setNazwisko("Kowalski");
        System.out.println("id = " + pracownik1.id);

        System.out.println(pracownik1.getPensja());
        System.out.println(pracownik2.getPensja());

        pracownik2.setPensja(3000);

        System.out.println(pracownik1.getPensja());
        System.out.println(pracownik2.getPensja());


    }

}