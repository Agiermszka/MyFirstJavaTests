package InkrementacjaDekrementacja;


public class InkrementacjaDekrementacja {

    public static void main(String[] args) {
        int a= 1, b= 2, c, d;
        c= ++b; // b = b + 1; c = b;

        System.out.println("a= " + a);
        System.out.println("b= " + b);
        System.out.println("c= " + c);

        d = a++; // d = a; a= a + 1;
        System.out.println("a= " + a);
        System.out.println("b= " + b);
        System.out.println("c= " + c);
        System.out.println("d= " + d);

        c++;
        System.out.println("a= " + a);
        System.out.println("b= " + b);
        System.out.println("c= " + c);
        System.out.println("d= " + d);

    }
}
