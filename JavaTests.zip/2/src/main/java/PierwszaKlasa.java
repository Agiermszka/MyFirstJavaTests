public class PierwszaKlasa {

    public static void main(String[] args){
        System.out.println("cos tam");
        System.out.println(); // sout
        System.out.println();
    }

}
