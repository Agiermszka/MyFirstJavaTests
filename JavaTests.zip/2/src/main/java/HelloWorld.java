public class HelloWorld {
    // ciało klasy - instrukcje klasy

    public static void main(String[] args) {
        System.out.println("Hello World!");
        System.out.println("wdw");
        System.out.println("Ala ma kota \n\n\n");
        System.out.print("Olek ma psa");
    }

}

