package Objektowość;

public class PudełkoDemo {
    public static void main(String[] args) {
        Pudełko pudelko1 = new Pudełko(); // sami zdefiniowalismy sobie typ - obiekt!
        System.out.println(pudelko1.obliczPojemnosc());
        System.out.println("----------");

        pudelko1.setSzerokość(5.3);
        pudelko1.setGłębokość(2);
        pudelko1.setWysokość(10);

        pudelko1.obliczPojemnosc(); // 1 piesek
        System.out.println(pudelko1.obliczPojemnosc());

        Pudełko pudelko2 = new Pudełko();                 // 2 piesek
        pudelko2.setSzerokość(100);
        pudelko2.setWysokość(50);
        pudelko2.setGłębokość(10);
        System.out.println(pudelko2.obliczPojemnosc());
        pudelko2.setSzerokość(-6);
        System.out.println(pudelko2.obliczPojemnosc());

        System.out.println("Wysokosc pudelko1, to " + pudelko1.getWysokość());

        Pudełko pudełko3 = new Pudełko(10,4,2);
        System.out.println(pudełko3.obliczPojemnosc());

    }
}
