package Objektowość;

public class Pudełko {
    private double szerokość;  //szablon najpierw - cechy - rzeczowniki - pola (bez main) podobnie jak zmienne
    private double wysokość; // modyfikatory public - jawne / zmienić modyfikator dostępu
    private double głębokość;


    Pudełko() {
        this.szerokość = 0;
        this.głębokość = 0;
        this.wysokość = 0;
    }

    //konstruktory  Pudełko3 = new Pudełko(30,40,50);

    Pudełko(double szerokość, double wysokość, double głębokość) {
        this.szerokość = szerokość;
        this.wysokość = wysokość;
        this.głębokość = głębokość;

    }

    // Setery !!! udostępniamy za ich pomocą
    //pudelko1.setSzerokosc(11);

    public void setSzerokość(double width) { //nie będzie nic zwracał - ma tylko zwrócić wartość
        if (width > 0) {
            szerokość = width; //parametry metod - do jej wnętrza przekazywane jakieś wartości
        } else { //zabezpieczenia
            System.out.println("Wartość jest mniejsza niż 0, więc nie została wpisana do pola szerokość");
        }
    }

    //pudelko1.setGłębokość(6)
    public void setGłębokość(double głębokość) { //nazwa parametru czarna
        this.głębokość = głębokość;
    }

    public void setWysokość(double wysokość) {
        this.wysokość = wysokość;
    }

    public double getGłębokość() {
        return głębokość;
    }

    public double getSzerokość() {
        return szerokość;
    }

    public double getWysokość() { //gettery podbieramy skądś, ale nie przekazujemy do środka
        return this.wysokość;

    }

    public double obliczPojemnosc() {   //metoda - czynnosc - ma zwracać wartość - będzie zwracać typu double wartosc
        return szerokość * wysokość * głębokość;
    }

}
