package Objektowość;

public class Date {
    private int dzień;
    private int miesiąc;
    private int rok;

    public int getDzień() {
        return dzień;
    }

    public void setDzień(int dzień) {
        this.dzień = dzień;
    }

    public int getMiesiąc() {
        return miesiąc;
    }

    public void setMiesiąc(int miesiąc) {
        this.miesiąc = miesiąc;
    }

    public int getRok() {
        return rok;
    }

    public void setRok(int rok) {
        this.rok = rok;
    }


    public void wyswietlDate() {   //czynność - do wyświetlania - nic nie zwraca

        System.out.printf("%d/%d/%d",dzień, miesiąc, rok); //decimal d - wartości całkowitego , rezerwację na liczbę typu dziesiętnego
        //System.out.println(dzień + "/" + miesiąc + "/" + rok);

    }
}
