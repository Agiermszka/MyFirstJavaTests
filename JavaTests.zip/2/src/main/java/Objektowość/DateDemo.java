package Objektowość;

public class DateDemo {
    public static void main(String[] args) { //potrzeby metody main by użyć = wykorzystać
        Date date1 = new Date(); //obiekt tworzony na podstawie szablonu - wywołuję konstruktor bezparametrowy
        date1.setDzień(24);
        date1.setMiesiąc(11);
        date1.setRok(2021);
        date1.wyswietlDate();

    }
}
