public class InstrukcjeWarunkowe {

    public static void main(String[] args) {

        int zmienna = 6;

        if (zmienna == 5) {
            // instrukcje do wykonania
            System.out.println("W pudełku jest wartość 5");
            System.out.println("aaaaa");
        } else {
            System.out.println("W pudełku jest wartość inna niż 5");
        }

        // == <= >= !=

        if (zmienna == 5) {
            System.out.println("w pudełku jest wartość 5");
        } else if (zmienna == 6) {
            System.out.println("W pudełku jest wartość 6");
        } else if (zmienna == 7) {
            System.out.println("W pudełku jest wartość 7");
        } else {
            System.out.println("W pudełku nie ma ani 5 ani 6 ani 7");
        }

        System.out.println("-----------");
 }
}
