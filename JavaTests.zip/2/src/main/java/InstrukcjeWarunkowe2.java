public class InstrukcjeWarunkowe2 {
    public static void main(String[] args) {
        int x = 2, y = 20;

        // && (i)    || (lub)

        if ((x == 10) || (y == 20)) {
            System.out.println("to się wykona jeżeli x == 10 lub y == 20");
        }

        if ((x < -2) || (x >= 0 && x < 2) || (x >= 5)) {
            System.out.println("tak");
        } else
            System.out.println("nie");
    }
}


