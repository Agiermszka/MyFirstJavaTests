package ćwiczenia;

import java.util.Scanner;

public class Ćwiczenie17SDA {
    public static void main(String[] args) {
        Scanner klawiatura = new Scanner(System.in);
        System.out.println("Podaj liczbę: ");
        int pobranaWartosc = klawiatura.nextInt();

        if (pobranaWartosc % 3 == 0) {
            System.out.print("fizz");
        }

        if (pobranaWartosc % 5 == 0) {
            System.out.print("buzz");
        }
    }
}
