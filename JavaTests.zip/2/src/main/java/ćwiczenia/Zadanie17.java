package ćwiczenia;

import java.util.Scanner;

public class Zadanie17 {

    public static void main(String[] args) {
        Scanner readNumber = new Scanner(System.in);
        System.out.println("Podaj liczbę: ");
        int number = readNumber.nextInt();
        String fizzBuzzResult = fizzBuzz(number);
        System.out.println();
    }

    public static String fizzBuzz(int number) {
        if (number % 5 == 0) {
            if (number % 3 == 0) {
                return "fizzbuzz"; //sout
            } else {
                return "fizz";
            }
        } else if (number % 5 == 0) {
            return "buzz"; //sout
        }
        return String.valueOf(number);
    }
}