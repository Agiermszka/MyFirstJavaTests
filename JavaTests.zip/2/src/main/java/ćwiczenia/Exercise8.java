package ćwiczenia;

import java.util.Scanner;

public class Exercise8 {

    public static void main(String[] args) {

        Scanner readTemperature = new Scanner(System.in);

        // Get input user
        System.out.println("Podaj temperaturę ");
        double temp = 100;

        // Execute methods
        CtoF(temp);
        FtoC(temp);
        CtoK(temp);
        KtoC(temp);
        KtoF(temp);
        FtoK(temp);

    }

    // Celsius to Fahrenheit
    private static void CtoF(double temp) {
        System.out.println("C do F " + 1.8 * temp + 32);
    }

    // Fahrenheit to Celsius
    private static void FtoC(double temp) {
        System.out.println("F do C " + (temp - 32) / 1.8);
    }

    // Celsius to Kelvin
    private static void CtoK(double temp) {
        System.out.println("C do K " + temp + 273.15);
    }

    // Kelvin to Celsius
    private static void KtoC(double temp) {
        System.out.println("K do C " + (temp - 273.15));
    }

    // Kelvin to Fahrenheit
    private static void KtoF(double temp) {
        System.out.println("K do F " + (temp - 273.15)*1.8 + 32);
    }

    // Fahrenheit to Kelvin
    private static void FtoK(double temp) {
        System.out.println("F do K " + (temp - 32) / 1.8 + 273.15);
    }
}
