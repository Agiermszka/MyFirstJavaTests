package ćwiczenia;

public class Ćwiczenie5SDA {
    public static void main(String[] args) {

    // tablica = portfel, indeks = banknot

        int[] tablica;
        tablica = new int [10]; //stworzenie portfela do którego 10 elementów włożymy / rozmiar
        int minimum, maksimum; // 2 pudełka w pamięci - wrzucam wartości - na razie puste

        for(int indeks = 0; indeks < tablica.length ; indeks++) { //indeksy zaczynają się od 0
            tablica[indeks] = (int) (Math.random() * 20 - 10);
        }

        minimum = tablica[0]; // dopiero kiedy portfel zapełniony jakimiś elementami, dopiero potem przypisać tę wartość po tablicy fot
        maksimum = tablica[0]; //potencjalnie najmniejsze wartości

        for (int indeks = 0 ; indeks < tablica.length ; indeks++) {
            System.out.print(tablica[indeks] + " ");//pobieranie informacji z tablicy
            if (tablica[indeks] < minimum) {
                minimum = tablica[indeks]; // tu czy tu dlatego dwa if
            }
            if (tablica[indeks] > maksimum) {
                maksimum = tablica[indeks];
            }
        }
        System.out.println("\nmaksymalna wartosc to: " + maksimum);
        System.out.println("minimalna wartosc to: " + minimum);

    }
}