public class InstrukcjaWyboru {

    public static void main(String[] args) {

        int zmienna = 1;

        switch (zmienna) {
            case 1:
                System.out.println("1");
                break;
            case 2:
                System.out.println("2");
                break;
            case 3:
                System.out.println("3");
                break;
            default:
                System.out.println("cos tam");
        }

        System.out.println(".........\n");
    }
}
