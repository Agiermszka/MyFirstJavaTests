public class ZasięgZmiennych {

    public static void main(String[] args) {
        int x = 10;

        if (x == 10) {
            System.out.println("x= " + x);
            int y = 20;
            System.out.println("y= " + y);
        }
        x = 30;
        System.out.println("x= " + x);
        // y = 40;

        x += 4 ; // x= x + 4
        System.out.println(x);

        x -= 4; //x= x - 4
        x *= 3; // x= x * 3;
        x++; // x= x + 1
        ++x; // x= x + 1
       // c += a * b; // c = c + (a * b);
        // c %= 6; // c = c % 6; c= 51 % 6 = 3
        x += 3; // x = x + 3


    }
}