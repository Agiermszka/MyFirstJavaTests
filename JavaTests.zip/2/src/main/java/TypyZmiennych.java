public class TypyZmiennych {

    public static void main(String[] args) {
        int liczbaCalkowita;
        liczbaCalkowita = 128;

        double liczbaRzeczywista = 228.9;

        char zmiennaZnakowa = 'c';
        boolean zmiennaLogiczna = true;

        System.out.println("Liczba całkowita = " + liczbaCalkowita + " PLN");
        System.out.println(liczbaRzeczywista);
        System.out.println(zmiennaLogiczna);

        zmiennaLogiczna = false;
        System.out.println(zmiennaLogiczna);
        System.out.println(zmiennaZnakowa);

        System.out.println(liczbaCalkowita + liczbaRzeczywista);

        char zmiennaZnakowa2 = 169;
        System.out.println(zmiennaZnakowa2);
        System.out.println(zmiennaZnakowa + zmiennaZnakowa2);

        final double STALA_PI = 3.1416;
        System.out.println("Drukuj PI" + STALA_PI);


    }
}
