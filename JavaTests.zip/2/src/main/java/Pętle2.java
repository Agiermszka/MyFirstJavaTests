public class Pętle2 {

    public static void main(String[] args) {

        int[] tablica = {3, 5, 8, 1};
        //System.out.println(tablica[0]);
        //System.out.println(tablica[1]);
        System.out.println(tablica.length);


        // i = indeksy

        for (int i = 0; i <= 3; i++) { // o 1 mniejszy indeks
            System.out.println(tablica[i]);
        }
        System.out.println("------------");

        for (int i = 0; i < tablica.length; i++) {
            System.out.println(tablica[i]);
        }

        System.out.println("------------");

        for (int pobranyElement : tablica) {   //for each pętla (nie ma w materiałach)
            System.out.println(pobranyElement); //dedykowana takim jednowymiarowym tablicom
        } // tablica to źródło informacji, pobrany element to argument - zapamiętany element


        int [][] macierz = new int[2][3];
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 3; j++) { // w tej pętli for mieliśmy wpisywaną każdą wartość (2)
              //  macierz[i][j] = 9;      // wpisywanie!

                macierz[i][j] = (int) (Math.random() * 20 - 10);


            }
        }


        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(macierz[i][j] + "  "); //instrukacja pobierania wartości(1)
            }                                            //pobieranie
            System.out.println(); //przechodząc trafia na to // żeby ładnie wyglądało

        }

        System.out.println("------------");

    }

}