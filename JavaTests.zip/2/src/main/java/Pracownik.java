public class Pracownik {

    static int id;
    static double pensja; //wspólne dla wszystkich obiektów = pracowników
    private String imię;
    private String nazwisko;
    private String stanowisko;

    public Pracownik() {
        id++;
    }

    public static double getPensja() {
        return pensja;
    }

    public static void setPensja(double pensja) {
        Pracownik.pensja = pensja;
    }

    public String getImię() {
        return imię;
    }

    public void setImię(String imię) {
        this.imię = imię;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public String getStanowisko() {
        return stanowisko;
    }

    public void setStanowisko(String stanowisko) {
        this.stanowisko = stanowisko;
    }

}
