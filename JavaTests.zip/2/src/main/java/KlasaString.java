import java.util.Locale;

public class KlasaString {

    public static void main(String[] args) {
        int x = 1;

        char c = 'a';

        String łancuchZnaków = "Ala ma kota";
        łancuchZnaków = "Olek ma psa";
        System.out.println(łancuchZnaków);
        System.out.println(łancuchZnaków.length());

        String łancuchZnakow2 = łancuchZnaków.toUpperCase();
        String łancuchZnakow4 = łancuchZnaków.toLowerCase();

        System.out.println(łancuchZnakow2);
        System.out.println(łancuchZnaków);
        System.out.println(łancuchZnakow4);

        String łancuchZnakow3 = "Olek ma psa";


        if (łancuchZnaków == "Olek ma psa") {
            System.out.println(true);
        }

        //if lancuch znaków == "Olek ma psa"
        if (łancuchZnaków.equals("Olek ma psa")) {
            System.out.println(true);
        }
    }
}
