package Praca_domowa;

import java.util.Scanner;

public class Ćwiczenie3 {

    public static void main(String[] args) {
        Scanner klawiatura = new Scanner(System.in);
        System.out.println("Podaj wartosc całkowita dodatnia : ");
        int wartosc = klawiatura.nextInt();

        int i = 1;

        while (i <= wartosc) {
          //  System.out.print(i + " ");
           //  i +=2 ;

           // if (i % 2 == 1)
            if (i % 2 !=0) {  //wartośc przeciwna do liczby parzystej
                            // if (i % 2 = 0 ) parzyste!
                System.out.println(i + " ");
            }
            i++; // zwiększ o 1 bo będę sprawdzać każdą kolejną wartość

        }

        // for (i = 1; i <= wartosc; i++)
    }
}
