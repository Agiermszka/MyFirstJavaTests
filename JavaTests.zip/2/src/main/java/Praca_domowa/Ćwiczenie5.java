package Praca_domowa;

import java.util.Scanner;

public class Ćwiczenie5 {

    public static void main(String[] args) {
        Scanner klawiatura = new Scanner(System.in);
        System.out.println("Podaj wartość całkowitą dodatnią: ");
        int wartosc = klawiatura.nextInt(); //muszę ją zapamiętać w jakieś zmiennej

        int i = 1; // to ta będzie wypisywana na ekranie wartość


        while (i <= wartosc) { //powtarzaj jakąś czynność dopóki będzie spełniony warunek
            System.out.print(i + " ");
            i += 2;
        }

        System.out.println();

        for (i = 1 ; i <= wartosc ; i++) {
            if (i % 2 != 0) {
                System.out.print(i + " ");
            }
             // zwiększ o 1 bo będę sprawdzać każdą kolejną wartość
        }
    }

}
