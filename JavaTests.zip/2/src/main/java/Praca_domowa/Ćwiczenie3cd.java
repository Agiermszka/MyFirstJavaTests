package Praca_domowa;

public class Ćwiczenie3cd {

    public static void main(String[] args) {

        double stopnieCelsjusza = 20;
        double stopnieFahrenheita;

        stopnieFahrenheita = stopnieCelsjusza * 1.8 + 32; //kropka nie przecinek!

        System.out.println(stopnieCelsjusza + " stopni celsjusza, to jest "
                + stopnieFahrenheita + " stopni Fahrenheita");

    }

    }