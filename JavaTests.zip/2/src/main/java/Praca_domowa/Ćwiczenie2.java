package Praca_domowa;

import java.util.Scanner;

public class Ćwiczenie2 {

    public static void main(String[] args) {
        Scanner klawiatura = new Scanner(System.in);

        double cenaTowaru; //zmienne globalne
        double iloscRat;
        double oprocentowanie = 0;


        do {
            System.out.println("Podaj cene towaru : ");
            cenaTowaru = klawiatura.nextDouble();
            if (cenaTowaru < 100 || cenaTowaru > 10000) {
                System.out.println("Powinieneś podać cenę towaru między 100, a 10 000");
            }
        } while (cenaTowaru < 100 || cenaTowaru > 10000);

        do {
            System.out.println("Podaj ilość rat : ");
            iloscRat = klawiatura.nextInt();
            if (iloscRat < 6 || iloscRat > 48) {
                System.out.println("Powinieneś podać ilość rat między 6 a 48");
            }
        } while (iloscRat < 6 | iloscRat > 48);

        // double oprocentowanie = 0;

        if (iloscRat >= 6 && iloscRat <= 12) {
            oprocentowanie = 0.025;

        } else if (iloscRat >= 13 && iloscRat <= 24) {
            oprocentowanie = 0.05;
        } else if (iloscRat >= 25 && iloscRat <= 48) {
            oprocentowanie = 0.1;
        }

        System.out.println((cenaTowaru * oprocentowanie) + cenaTowaru / iloscRat);

    }
// nie ma zabezpieczenia
}