package Praca_domowa;

import java.util.Scanner;

public class Ćwiczenie1 {

    public static void main(String[] args) {

        Scanner klawiatura = new Scanner(System.in);
        System.out.println("Podaj wartość stopni Celsjusza: ");
        double stopnieCelsjusza = klawiatura.nextDouble();

        //double stopnieCelsjusza = 20;
        double stopnieFahrenheita;

        stopnieFahrenheita = stopnieCelsjusza * 1.8 + 32;
        System.out.println(stopnieCelsjusza + " stopni celsjusza, to jest "
                + stopnieFahrenheita + " stopni Fahrenheita");


    }
}
